package com.cg.onnlineshop;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.embedded.LocalServerPort;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.test.context.junit4.SpringRunner;
@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = WebEnvironment.RANDOM_PORT)
public class CgOnlineShopingRestFulSpringBootApplicationTests {
	@LocalServerPort
	private int port;
	
	
	@Autowired
	private TestRestTemplate restTemplate;
	
	@Test
	public void contextLoads() {
	}
	
	@Test
	public void getHello() {
		assertThat(this.restTemplate.getForObject("http://localhost:" + port + "/", String.class)).contains("Hello World");
	} 
	
	/*@Test
	public void getEmployee() {
		Employee emp = this.restTemplate.getForObject("http://localhost:" + port + "/employee/101", Employee.class);
		assertThat(emp.getId().equals("101"));
		assertThat(emp.getName().equals("ABC"));
	} 
	
	
	@Test
	public void getAllEmployee() {
		ArrayList<Employee> list = this.restTemplate.getForObject("http://localhost:" + port + "/employees", ArrayList.class);
		assertThat(list != null);
		assertThat(list.size() == 3);
	} 
	
	@Test
	public void delEmployee() {
		assertThat(this.restTemplate.getForObject("http://localhost:" + port + "/delete/101", Employee.class));
	}
	
	
	@Test
	public void addEmployee() {
		this.restTemplate.exchange(requestEntity, responseType)("http://localhost:" + port + "/add", Employee.class)
		assertThat();
		
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);

		MultiValueMap<String, String> map= new LinkedMultiValueMap<String, String>();
		map.add("id", "104");
		map.add("name", "aaa");

		HttpEntity<MultiValueMap<String, String>> request = new HttpEntity<MultiValueMap<String, String>>(map, headers);

		ResponseEntity<String> response = restTemplate.postForEntity( "http://localhost:" + port + "/add", request , String.class );
		
		
		
		Employee e = new Employee("104","AAA");

	    MultiValueMap<String, Object> parameters = new LinkedMultiValueMap<String, Object>();
	    parameters.add("obj", e);

	    HttpHeaders headers = new HttpHeaders();
	    headers.setContentType(MediaType.APPLICATION_JSON);

	    HttpEntity<MultiValueMap<String, Object>> entity = new HttpEntity<MultiValueMap<String, Object>>(parameters, headers);

	    ResponseEntity<String> response = restTemplate.exchange("http://localhost:" + port + "/add", HttpMethod.POST, entity, String.class, "");

	    assertThat(response.getBody().equals("true"));
	    
		
	}
	
	@Test
	public void updateEmployee() {
			
		Employee e = new Employee("104","AAA");

	    MultiValueMap<String, Object> parameters = new LinkedMultiValueMap<String, Object>();
	    parameters.add("obj", e);

	    HttpHeaders headers = new HttpHeaders();
	    headers.setContentType(MediaType.APPLICATION_JSON);

	    HttpEntity<MultiValueMap<String, Object>> entity = new HttpEntity<MultiValueMap<String, Object>>(parameters, headers);

	    ResponseEntity<String> response = restTemplate.exchange("http://localhost:" + port + "/add", HttpMethod.PUT, entity, String.class, "");

	    assertThat(response.getBody().equals("true"));
	    
		
	}*/
}
