package com.cg.onlineshop.services;

import java.util.ArrayList;

import com.cg.onlineshop.beans.Product;

public interface OnlineShopServices {
	public void acceptProductDetails(Product product);
	public ArrayList<Product> getAllProductDetails();
	public Product getProductDetails();
	
	
}
