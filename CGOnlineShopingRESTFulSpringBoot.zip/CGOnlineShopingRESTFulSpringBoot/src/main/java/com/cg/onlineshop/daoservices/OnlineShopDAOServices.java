package com.cg.onlineshop.daoservices;

import java.util.ArrayList;

import com.cg.onlineshop.beans.Product;

public interface OnlineShopDAOServices {
	public void insertProduct(Product product);
	public void updateProduct(Product product);
	public void deleteProduct(int productCode);
	public ArrayList<Product> getAllProducts();
	public Product getProduct();
	
}
