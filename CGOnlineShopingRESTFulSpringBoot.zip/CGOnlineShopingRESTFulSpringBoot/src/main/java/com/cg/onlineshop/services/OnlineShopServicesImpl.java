package com.cg.onlineshop.services;

import java.util.ArrayList;

import org.springframework.stereotype.Service;

import com.cg.onlineshop.beans.Product;

@Service(value="onlineShopServices")
public class OnlineShopServicesImpl implements OnlineShopServices{

	@Override
	public void acceptProductDetails(Product product) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public ArrayList<Product> getAllProductDetails() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Product getProductDetails() {
		// TODO Auto-generated method stub
		return null;
	}

}
