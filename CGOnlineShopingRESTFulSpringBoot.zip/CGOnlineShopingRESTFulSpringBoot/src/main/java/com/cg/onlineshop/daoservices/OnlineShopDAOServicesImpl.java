package com.cg.onlineshop.daoservices;
import java.util.ArrayList;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import com.cg.onlineshop.beans.Product;
@Repository(value="onlineShopDAOServices")
@Transactional(propagation=Propagation.REQUIRED)
public class OnlineShopDAOServicesImpl implements OnlineShopDAOServices{

	@PersistenceContext 
	EntityManager entityManager;
	@Override
	public void insertProduct(Product product) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void updateProduct(Product product) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deleteProduct(int productCode) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public ArrayList<Product> getAllProducts() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Product getProduct() {
		// TODO Auto-generated method stub
		return null;
	}

}
